using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour
{
    // WASD 
    // Start is called before the first frame update

    public GameObject Player;

    public int playerHealth = 3;

    private float speed = 35.0f;

    public Rigidbody rigidbody;

    public int CoinCount; 

    bool HasKey;

    void Start()
    {
        
    }



    // Update is called once per frame
    void Update()
    {
        
        if (Input.GetKeyDown("w"))
        {
            transform.position += Vector3.up * speed * Time.deltaTime;
        }
        if (Input.GetKeyDown("a"))
        {
            transform.position += Vector3.left * speed * Time.deltaTime;
        }
        if (Input.GetKeyDown("s"))
        {
            transform.position += Vector3.down * speed * Time.deltaTime;
        }
        if (Input.GetKeyDown("d"))
        {
            transform.position += Vector3.right * speed * Time.deltaTime;
        }

    }


    private void OnCollisionEnter(Collision collision)
    {
        // search for the player when it touches the player it destroys the key and add it to the player inventory
        if (collision.gameObject.name == "Key")
        {
            Destroy(this.transform.gameObject);

            bool Haskey = true;
        }
    }

    public void OnTriggerEnter(Collider other)
    {
        if (other.name == "trap")
        {
            playerHealth--;
        }

    }


    public void OnCollisionEnter(Collider other)
    {
        if (other.name == "Door")
        {
            if(HasKey == true)
            {
                Debug.Log("You may go to the next room");
            }
        }

    }

    /* public void OnTriggerEnter(Collider other)
     {
         if (other.name == "coin")
         {
             CoinCount++;
         }

     }*/

    private void OnCollisionExit(Collision collision)
    {
        if (collision.gameObject.name == "coin")
        {
            Destroy(this.transform.gameObject);

            CoinCount++;
        }
    }

}
